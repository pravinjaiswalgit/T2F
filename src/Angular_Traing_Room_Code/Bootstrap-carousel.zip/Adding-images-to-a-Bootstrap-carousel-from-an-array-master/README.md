# Carousel
The demo which accompanies my blog post [Angular: Adding images to a Bootstrap carousel from an array](https://oraclefrontovik.com/2020/05/28/angular-adding-images-to-a-bootstrap-carousel-from-an-array/)
