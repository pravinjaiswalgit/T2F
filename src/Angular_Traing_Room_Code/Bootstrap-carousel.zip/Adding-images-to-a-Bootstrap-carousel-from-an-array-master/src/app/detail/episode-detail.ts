export interface IEpisodeDetail {
    id: number;
    title: string;
    productionYear: string;
    synopsis: string;    
    imageUrls: string[];
}
